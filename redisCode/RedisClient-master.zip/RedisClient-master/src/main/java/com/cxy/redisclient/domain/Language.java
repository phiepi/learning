package com.cxy.redisclient.domain;

public enum Language {
	English, Chinese;
}
