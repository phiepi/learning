package com.cxy.redisclient.domain;

public enum ValueType {
	StringValue, BinaryValue;
}
