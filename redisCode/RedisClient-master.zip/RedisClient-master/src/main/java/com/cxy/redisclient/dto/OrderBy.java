package com.cxy.redisclient.dto;

public enum OrderBy {
	NAME, TYPE, SIZE;
}
