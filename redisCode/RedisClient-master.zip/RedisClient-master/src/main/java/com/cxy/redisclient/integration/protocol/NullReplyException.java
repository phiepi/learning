package com.cxy.redisclient.integration.protocol;

public class NullReplyException extends RuntimeException {

	private static final long serialVersionUID = -2269722804318808889L;

	public NullReplyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
