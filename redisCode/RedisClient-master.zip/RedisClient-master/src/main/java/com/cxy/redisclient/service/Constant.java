package com.cxy.redisclient.service;

public class Constant {
	static final String CODEC = "ISO-8859-1";
	static final String VALUE = "value";
	static final String KEY = "key";
	static final String MAXID = "maxid";
}
